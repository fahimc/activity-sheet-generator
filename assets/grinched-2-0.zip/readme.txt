OTF: Grinched 2.0 (Updated 2/22/2017)
Dennis Ludlow 2015 all rights reserved
by Sharkshock 
dennis@sharkshock.net


Thanks for taking a look! Grinched was my most popular font by far and after several years in need of some updating. After some tweaking here and there the decision was made 
to completely redraw it keeping several of the original characters intact. 80% of the uppercase letters made their way back into the newer version while nearly all of the lowercase were 
replaced and redrawn completely. Each letter was carefully re-edited for maximum sharpness and magnification at large sizes. Cyrillic characters were added for Russian and Ukranian users. 

Basic and extended latin, numbers, punctuation, European accents, diacritics, Cyrillic, and kerning are included in the full version. Basic Latin, numbers, 
and limited punctuation are included in the free demo. 

The complete version is available with purchase of commercial license or $20 via PayPal. Please note that this $20 is for PERSONAL use only and does not constitute a commercial license.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user
license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom fonts for companies, logos, and many other things. If you'd like to leave 
me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: display, font, typeface, publishing, logo, title, book, sports, game, Russian, diacritics, French, Polish, Sharkshock, German, Portuguese, European, sans, weight, 
line, cartoon, wacky, kids, children, childrens, Seuss, show, TV, update, Christmas, holiday, theme


